# Android Release — المرحلة 10

الهيكل صار جاهزًا للربط مع السيرفر الحقيقي.

قبل بناء APK/AAB:
1. استبدل `https://YOUR-DOMAIN.example` بعنوان السيرفر الحقيقي.
2. أضف `google-services.json` بعد إنشاء Firebase project.
3. فعّل Firebase Cloud Messaging.
4. اربط token الجهاز بحساب المستخدم.
5. اختبر Android 13+ إذن الإشعارات.
6. وقّع AAB بمفتاح release خاص.
7. اختبر رفع/تنزيل STL والصور.
8. اختبر تسجيل الدخول والخروج وانتهاء الجلسة.

لا تضع مفاتيح سرية أو Service Role Key داخل تطبيق Android.
