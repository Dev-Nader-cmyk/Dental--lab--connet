const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const PORT=process.env.PORT||3000, ROOT=__dirname, DB=path.join(ROOT,"data","db.json"), UP=path.join(ROOT,"uploads");
for(const d of [path.dirname(DB),UP])if(!fs.existsSync(d))fs.mkdirSync(d,{recursive:true});
if(!fs.existsSync(DB))fs.writeFileSync(DB,JSON.stringify({users:[
{id:"doc1",name:"د. أحمد",role:"doctor",phone:"07000000001",passwordHash:hash("1234"),labs:["lab1"]},
{id:"lab1",name:"مختبر الإبداع",role:"lab",phone:"07000000002",passwordHash:hash("1234"),labs:[]}
],sessions:{},cases:[],messages:[],audit:[]},null,2));
function hash(s){return crypto.createHash("sha256").update(s).digest("hex")}
function db(){return JSON.parse(fs.readFileSync(DB,"utf8"))} function save(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
function json(res,code,o){res.writeHead(code,{"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"GET,POST,PUT,OPTIONS"});res.end(JSON.stringify(o))}
function parse(req){return new Promise((ok,bad)=>{let s="";req.on("data",c=>{s+=c;if(s.length>2e6)req.destroy()});req.on("end",()=>{try{ok(s?JSON.parse(s):{})}catch(e){bad(e)}})})}
function token(){return crypto.randomBytes(32).toString("hex")}
function auth(req,D){let t=(req.headers.authorization||"").replace("Bearer ","");let uid=D.sessions[t];return uid?D.users.find(u=>u.id===uid):null}
function id(){return crypto.randomBytes(5).toString("hex")}
function log(D,u,action,caseId){D.audit.push({id:id(),userId:u?.id||null,action,caseId:caseId||null,time:new Date().toISOString()});if(D.audit.length>1000)D.audit=D.audit.slice(-1000)}
function canSee(u,c){return u.role==="lab"?c.labId===u.id:c.doctorId===u.id}
const srv=http.createServer(async(req,res)=>{
 if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*"});res.end();return}
 const U=new URL(req.url,`http://${req.headers.host}`),D=db();
 try{
  if(U.pathname==="/api/health"){json(res,200,{ok:true,version:"5.0"});return}
  if(U.pathname==="/api/register"&&req.method==="POST"){
   const b=await parse(req);if(!b.phone||!b.password||!b.role||!b.name)return json(res,400,{error:"البيانات ناقصة"});
   if(D.users.some(u=>u.phone===b.phone))return json(res,409,{error:"رقم الهاتف مستخدم"});
   const u={id:id(),name:b.name,role:b.role,phone:b.phone,passwordHash:hash(b.password),labs:[]};D.users.push(u);save(D);json(res,201,{id:u.id,name:u.name,role:u.role});return}
  if(U.pathname==="/api/login"&&req.method==="POST"){
   const b=await parse(req),u=D.users.find(x=>x.phone===b.phone&&x.role===b.role&&x.passwordHash===hash(b.password||""));
   if(!u)return json(res,401,{error:"رقم الهاتف أو كلمة المرور غير صحيحة"});
   const t=token();D.sessions[t]=u.id;save(D);json(res,200,{token:t,user:{id:u.id,name:u.name,role:u.role}});return}
  const u=auth(req,D);if(!u)return json(res,401,{error:"يجب تسجيل الدخول"});
  if(U.pathname==="/api/me")return json(res,200,{id:u.id,name:u.name,role:u.role});
  if(U.pathname==="/api/labs"&&req.method==="GET")return json(res,200,D.users.filter(x=>x.role==="lab").map(x=>({id:x.id,name:x.name})));

  if(U.pathname==="/api/dashboard"&&req.method==="GET"){
   if(u.role!=="lab")return json(res,403,{error:"غير مسموح"});
   const mine=D.cases.filter(c=>c.labId===u.id);
   const doctors=[...new Set(mine.map(c=>c.doctorId))].map(id=>{const c=mine.find(x=>x.doctorId===id);return {doctorId:id,doctorName:c.doctorName,cases:mine.filter(x=>x.doctorId===id).length,revenue:mine.filter(x=>x.doctorId===id&&x.price).reduce((a,x)=>a+Number(x.price||0),0)}});
   const today=new Date().toISOString().slice(0,10);
   const overdue=mine.filter(c=>c.deliveryDate&&c.deliveryDate<today&&c.status!=="done").length;
   const revenue=mine.reduce((a,c)=>a+Number(c.price||0),0);
   return json(res,200,{total:mine.length,new:mine.filter(c=>c.status==="new").length,work:mine.filter(c=>c.status==="work").length,ready:mine.filter(c=>c.status==="ready").length,done:mine.filter(c=>c.status==="done").length,overdue,revenue,doctors});
  }
  const rating=U.pathname.match(/^\/api\/cases\/([^/]+)\/rating$/);
  if(rating){
   const c=D.cases.find(x=>x.id===rating[1]);if(!c)return json(res,404,{error:"الحالة غير موجودة"});if(!canSee(u,c))return json(res,403,{error:"ليس لديك صلاحية"});
   if(req.method==="POST"){
    if(u.role!=="doctor"||c.status!=="done")return json(res,400,{error:"التقييم متاح للطبيب بعد التسليم فقط"});
    const b=await parse(req),score=Number(b.score);
    if(score<1||score>5)return json(res,400,{error:"التقييم من 1 إلى 5"});
    c.rating={score,comment:String(b.comment||""),time:new Date().toISOString(),doctorId:u.id};save(D);log(D,u,"RATE_CASE",c.id);return json(res,201,c.rating);
   }
   if(req.method==="GET")return json(res,200,c.rating||null);
  }

  if(U.pathname==="/api/cases"&&req.method==="GET")return json(res,200,D.cases.filter(c=>canSee(u,c)));
  if(U.pathname==="/api/cases"&&req.method==="POST"){
   if(u.role!=="doctor")return json(res,403,{error:"فقط الطبيب ينشئ الحالة"});
   const b=await parse(req),lab=D.users.find(x=>x.id===b.labId&&x.role==="lab");
   if(!lab)return json(res,400,{error:"المختبر غير موجود"});
   const c={id:id(),doctorId:u.id,doctorName:u.name,labId:lab.id,labName:lab.name,patientCode:b.patientCode,work:b.work,tooth:b.tooth,shade:b.shade,deliveryDate:b.deliveryDate,notes:b.notes,status:"new",price:null,labNotes:"",files:[],created:new Date().toISOString(),updated:new Date().toISOString()};
   D.cases.push(c);log(D,u,"CREATE_CASE",c.id);save(D);return json(res,201,c)}
  const cm=U.pathname.match(/^\/api\/cases\/([^/]+)$/);
  if(cm){
   const c=D.cases.find(x=>x.id===cm[1]);if(!c)return json(res,404,{error:"الحالة غير موجودة"});if(!canSee(u,c))return json(res,403,{error:"ليس لديك صلاحية لهذه الحالة"});
   if(req.method==="GET")return json(res,200,c);
   if(req.method==="PUT"){
    const b=await parse(req);
    if(u.role==="lab"){if(b.status&&!["new","work","ready","done"].includes(b.status))return json(res,400,{error:"حالة غير صحيحة"});if(b.status)c.status=b.status;if(b.price!==undefined)c.price=b.price;if(b.labNotes!==undefined)c.labNotes=b.labNotes}
    c.updated=new Date().toISOString();log(D,u,"UPDATE_CASE",c.id);save(D);return json(res,200,c)}
  }
  const mm=U.pathname.match(/^\/api\/cases\/([^/]+)\/messages$/);
  if(mm){const c=D.cases.find(x=>x.id===mm[1]);if(!c)return json(res,404,{error:"الحالة غير موجودة"});if(!canSee(u,c))return json(res,403,{error:"ليس لديك صلاحية"});
   if(req.method==="GET")return json(res,200,D.messages.filter(m=>m.caseId===c.id));
   if(req.method==="POST"){const b=await parse(req);if(!b.text)return json(res,400,{error:"الرسالة فارغة"});const m={id:id(),caseId:c.id,userId:u.id,userName:u.name,text:b.text,time:new Date().toISOString()};D.messages.push(m);log(D,u,"MESSAGE",c.id);save(D);return json(res,201,m)}}
  if(U.pathname==="/api/audit"&&req.method==="GET"){if(u.role!=="lab")return json(res,403,{error:"غير مسموح"});return json(res,200,D.audit.slice(-100).reverse())}
  const raw=U.pathname.match(/^\/api\/cases\/([^/]+)\/files$/);
  if(raw && req.method==="POST"){
   const c=D.cases.find(x=>x.id===raw[1]);
   if(!c)return json(res,404,{error:"الحالة غير موجودة"});
   if(!canSee(u,c))return json(res,403,{error:"ليس لديك صلاحية"});
   const original=U.searchParams.get("name")||"file.bin";
   const clean=original.replace(/[^a-zA-Z0-9._-]/g,"_").slice(0,120);
   const fileId=id(), target=path.join(UP,`${c.id}-${fileId}-${clean}`);
   const max=100*1024*1024; let bytes=0, rejected=false;
   const ws=fs.createWriteStream(target);
   req.on("data",chunk=>{bytes+=chunk.length;if(bytes>max){rejected=true;req.destroy();ws.destroy();try{fs.unlinkSync(target)}catch{};return}ws.write(chunk)});
   req.on("end",()=>{if(rejected)return;ws.end();const f={id:fileId,name:original,bytes,url:"/api/files/"+encodeURIComponent(path.basename(target)),time:new Date().toISOString()};c.files.push(f);c.updated=new Date().toISOString();log(D,u,"UPLOAD_FILE",c.id);save(D);json(res,201,f)});
   return;
  }
  const fr=U.pathname.match(/^\/api\/files\/(.+)$/);
  if(fr && req.method==="GET"){
   const filename=path.basename(decodeURIComponent(fr[1]));
   const file=path.join(UP,filename);
   const c=D.cases.find(x=>x.files.some(f=>f.url.endsWith(encodeURIComponent(filename))));
   if(!c||!canSee(u,c)||!fs.existsSync(file))return json(res,404,{error:"الملف غير موجود"});
   res.writeHead(200,{"Content-Type":"application/octet-stream","Content-Disposition":`attachment; filename="${filename.replace(/"/g,"")}"`});
   fs.createReadStream(file).pipe(res);return;
  }
  if(req.method==="GET"){
   let f=U.pathname==="/"?"index.html":U.pathname.slice(1),p=path.join(ROOT,"public",f);
   if(fs.existsSync(p)&&fs.statSync(p).isFile()){let ext=path.extname(p),ct={".html":"text/html; charset=utf-8",".js":"text/javascript",".css":"text/css",".json":"application/json"}[ext]||"application/octet-stream";res.writeHead(200,{"Content-Type":ct});fs.createReadStream(p).pipe(res);return}
  }
  json(res,404,{error:"Not found"})
 }catch(e){console.error(e);json(res,500,{error:"خطأ داخلي"})}
});
srv.listen(PORT,()=>console.log("Dental Lab Connect v5: http://localhost:"+PORT));