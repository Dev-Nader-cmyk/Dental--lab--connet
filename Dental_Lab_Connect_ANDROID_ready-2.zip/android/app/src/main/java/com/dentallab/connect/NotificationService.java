package com.dentallab.connect;
/*
 * Placeholder for Firebase Cloud Messaging integration.
 * Production steps:
 * 1) Add Firebase Android SDK.
 * 2) Add google-services.json.
 * 3) Store device token on the backend.
 * 4) Send notifications for new cases/status changes/messages.
 */
public class NotificationService { }