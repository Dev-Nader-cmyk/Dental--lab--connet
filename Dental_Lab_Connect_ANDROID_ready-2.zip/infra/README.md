# البنية الأونلاين

المشروع المحلي الحالي يعمل بـ Node.js + JSON للتجربة.
للإطلاق نستخدم PostgreSQL/Supabase.

الخطوات:
1. إنشاء مشروع PostgreSQL/Supabase.
2. تنفيذ schema.sql.
3. إنشاء Storage bucket خاص باسم case-files.
4. عدم جعل bucket عامًا.
5. استخدام signed URLs للتحميل.
6. نقل كلمات المرور إلى Auth provider.
7. إضافة RLS بحيث الطبيب يرى حالات doctor_id الخاصة به والمختبر يرى lab_id الخاصة به.
8. إضافة Edge Functions/API server للتحديثات الحساسة.
