
-- Dental Lab Connect production schema (PostgreSQL/Supabase compatible)
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  role text not null check (role in ('doctor','lab')),
  phone text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists cases (
  id uuid primary key default gen_random_uuid(),
  doctor_id uuid not null references profiles(id),
  lab_id uuid not null references profiles(id),
  patient_code text not null,
  work text not null,
  tooth text,
  shade text,
  delivery_date date,
  notes text,
  status text not null default 'new' check (status in ('new','work','ready','done')),
  price numeric(12,2),
  lab_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists case_files (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  uploader_id uuid not null references profiles(id),
  file_name text not null,
  storage_path text not null,
  mime_type text,
  size_bytes bigint,
  created_at timestamptz not null default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  text text not null,
  created_at timestamptz not null default now()
);

create table if not exists ratings (
  id uuid primary key default gen_random_uuid(),
  case_id uuid unique not null references cases(id) on delete cascade,
  doctor_id uuid not null references profiles(id),
  score int not null check (score between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  case_id uuid references cases(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists cases_doctor_idx on cases(doctor_id);
create index if not exists cases_lab_idx on cases(lab_id);
create index if not exists cases_status_idx on cases(status);
create index if not exists messages_case_idx on messages(case_id);
create index if not exists files_case_idx on case_files(case_id);
