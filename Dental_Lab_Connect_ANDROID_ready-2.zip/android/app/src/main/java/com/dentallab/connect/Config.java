package com.dentallab.connect;
public final class Config {
    private Config(){}
    public static final String API_BASE_URL = "https://YOUR-DOMAIN.example";
}