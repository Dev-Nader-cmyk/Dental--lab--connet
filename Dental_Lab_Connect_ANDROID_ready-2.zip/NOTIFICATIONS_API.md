# إشعارات التطبيق

الأحداث المقترحة:
- CASE_CREATED: حالة جديدة للمختبر.
- CASE_ACCEPTED: المختبر بدأ العمل.
- CASE_READY: الحالة جاهزة.
- CASE_DELIVERED: تم التسليم.
- NEW_MESSAGE: رسالة جديدة.
- PAYMENT_UPDATED: تحديث مالي.

Payload مثال:
{
  "type": "NEW_MESSAGE",
  "caseId": "CASE_ID",
  "title": "رسالة جديدة",
  "body": "لديك رسالة من المختبر"
}

يجب إرسال الإشعار من السيرفر وليس من تطبيق الهاتف مباشرة.
