package com.dentallab.connect;
import android.app.*; import android.os.*; import android.webkit.*; import android.content.*;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){
   super.onCreate(b);
   web=new WebView(this);
   web.getSettings().setJavaScriptEnabled(true);
   web.getSettings().setDomStorageEnabled(true);
   web.setWebViewClient(new WebViewClient());
   web.setWebChromeClient(new WebChromeClient());
   web.loadUrl(Config.API_BASE_URL);
   setContentView(web);
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}